<link rel="stylesheet" href="{{ asset('css/index.min.css') }}?v={{ env('APP_VERSION') }}" />
<link rel="stylesheet" href="{{ asset('css/app.min.css') }}?v={{ env('APP_VERSION') }}" />
