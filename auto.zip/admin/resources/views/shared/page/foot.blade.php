<div slot="footer" id="footer-content">
    <ul class="separater">
        <li></li>
        <li></li>
        <li></li>
    </ul>
    <ul id="content">
        <li>
            {{ url('/', secure: true) }}
        </li>
    </ul>
</div>
