<div slot="header" id="header-content">
    <img id="logo" src="{{ asset('img/logo.webp') }}?v={{ env('APP_VERSION') }}" />
    <ul class="separater">
        <li></li>
        <li></li>
        <li></li>
    </ul>
</div>
