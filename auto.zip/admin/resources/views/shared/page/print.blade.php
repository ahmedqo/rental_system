<img slot="top" id="backgroun-image" src="{{ asset('img/logo.webp') }}?v={{ env('APP_VERSION') }}" />
@include('shared.page.head')
@include('shared.page.foot')
