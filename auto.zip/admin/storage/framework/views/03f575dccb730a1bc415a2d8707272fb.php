
<?php $__env->startSection('title', __('Payments list')); ?>


<?php $__env->startSection('meta'); ?>
    <meta name="routes" content='<?php echo json_encode([
        'filter' => route('actions.payments.search'),
        'entire' => route('actions.payments.filter'),
        'patch' => route('views.payments.patch', 'XXX'),
    ]); ?>' />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="p-6 bg-x-white rounded-x-thin shadow-x-core">
        <neo-datavisualizer print search filter download title="<?php echo e(__('Payments list')); ?>">
            <neo-switch slot="start" id="filter" active></neo-switch>
            <?php echo $__env->make('shared.page.print', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </neo-datavisualizer>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('js/payment/index.min.js')); ?>?v=<?php echo e(env('APP_VERSION')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('shared.core.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH P:\php\auto\admin\resources\views/payment/index.blade.php ENDPATH**/ ?>