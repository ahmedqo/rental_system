
<?php $__env->startSection('title', __('New company')); ?>

<?php $__env->startSection('content'); ?>
    <form validate action="<?php echo e(route('actions.companies.store')); ?>" method="POST" enctype="multipart/form-data" class="w-full">
        <?php echo csrf_field(); ?>
        <neo-tab-wrapper outlet="outlet-1" class="w-full flex flex-col gap-6">
            <div class="flex flex-wrap items-center justify-between gap-2 lg:gap-6 relative isolate">
                <div class="absolute h-1 w-full bg-x-white left-0 right-0 top-1/2 -translate-y-1/2 z-[-1]">
                    <div id="track" class="absolute h-full top-0 bottom-0 w-0 bg-x-prime"></div>
                </div>
                <?php for($i = 1; $i <= 3; $i++): ?>
                    <neo-tab-trigger tabindex="0" slot="triggers" for="outlet-<?php echo e($i); ?>"
                        class="flex w-8 h-8 aspect-square items-center justify-center text-lg font-x-thin text-x-black bg-x-white rounded-x-thin outline-none hover:bg-x-acent hover:text-x-white focus:bg-x-acent focus:text-x-white">
                        <span><?php echo e($i); ?></span>
                        <svg class="hidden w-6 h-6 pointer-events-none text-x-prime" fill="currentcolor"
                            viewBox="0 -960 960 960">
                            <path
                                d="M261-167-5-433l95-95 172 171 95 95-96 95Zm240-32L232-467l97-95 172 171 369-369 96 96-465 465Zm-7-280-95-95 186-186 95 95-186 186Z" />
                        </svg>
                    </neo-tab-trigger>
                <?php endfor; ?>
            </div>
            <div class="p-6 bg-x-white rounded-x-thin shadow-x-core w-full flex flex-col gap-6">
                <neo-tab-outlet name="outlet-1" class="grid grid-cols-1 grid-rows-1 gap-6">
                    <div class="flex flex-col gap-1">
                        <label class="text-x-black font-x-thin text-base">
                            <?php echo e(__('Logo')); ?> (*)
                        </label>
                        <neo-imagetransfer rules="required" errors='{"required": "<?php echo e(__('The logo field is required')); ?>"}'
                            class="aspect-square lg:aspect-[16/5] p-2" placeholder="<?php echo e(__('Logo')); ?> (*)"
                            name="company_logo" value="<?php echo e(old('company_logo')); ?>"></neo-imagetransfer>
                    </div>
                    <div class="flex flex-col gap-1">
                        <label class="text-x-black font-x-thin text-base">
                            <?php echo e(__('Name')); ?> (*)
                        </label>
                        <neo-textbox rules="required" errors='{"required": "<?php echo e(__('The name field is required')); ?>"}'
                            placeholder="<?php echo e(__('Name')); ?> (*)" name="name" value="<?php echo e(old('name')); ?>"></neo-textbox>
                    </div>
                    <div class="flex flex-col gap-1">
                        <label class="text-x-black font-x-thin text-base">
                            <?php echo e(__('ICE number')); ?> (*)
                        </label>
                        <neo-textbox rules="required" errors='{"required": "<?php echo e(__('The ice number field is required')); ?>"}'
                            placeholder="<?php echo e(__('ICE number')); ?> (*)" name="ice_number"
                            value="<?php echo e(old('ice_number')); ?>"></neo-textbox>
                    </div>
                    <div class="flex flex-col gap-1">
                        <label class="text-x-black font-x-thin text-base">
                            <?php echo e(__('Decision number')); ?> (*)
                        </label>
                        <neo-textbox rules="required" errors='{"required": "<?php echo e(__('The decision number is required')); ?>"}'
                            placeholder="<?php echo e(__('Decision number')); ?> (*)" name="license_number"
                            value="<?php echo e(old('license_number')); ?>"></neo-textbox>
                    </div>
                    <div class="flex flex-col gap-1">
                        <label class="text-x-black font-x-thin text-base">
                            <?php echo e(__('Mileage per day')); ?> (*)
                        </label>
                        <neo-textbox rules="required"
                            errors='{"required": "<?php echo e(__('The mileage per day field is required')); ?>"}' type="number"
                            placeholder="<?php echo e(__('Mileage per day')); ?> (*)" name="mileage_per_day"
                            value="<?php echo e(old('mileage_per_day')); ?>"></neo-textbox>
                    </div>
                    <div class="flex flex-col gap-1">
                        <label class="text-x-black font-x-thin text-base">
                            <?php echo e(__('Status')); ?> (*)
                        </label>
                        <neo-select rules="required" errors='{"required": "<?php echo e(__('The status field is required')); ?>"}'
                            search placeholder="<?php echo e(__('Status')); ?> (*)" name="status">
                            <?php $__currentLoopData = Core::statsList(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <neo-select-item value="<?php echo e($status); ?>"
                                    <?php echo e($status == old('status', 'active') ? 'active' : ''); ?>>
                                    <?php echo e(ucfirst(__($status))); ?>

                                </neo-select-item>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </neo-select>
                    </div>
                </neo-tab-outlet>
                <neo-tab-outlet name="outlet-2" class="grid grid-cols-1 grid-rows-1 gap-6">
                    <div class="flex flex-col gap-1">
                        <label class="text-x-black font-x-thin text-base">
                            <?php echo e(__('Email')); ?> (*)
                        </label>
                        <neo-textbox rules="required|email"
                            errors='{"required": "<?php echo e(__('The email field is required')); ?>", "email": "<?php echo e(__('The email field must be a valid email')); ?>"}'
                            type="email" placeholder="<?php echo e(__('Email')); ?> (*)" name="email"
                            value="<?php echo e(old('email')); ?>"></neo-textbox>
                    </div>
                    <div class="flex flex-col gap-1">
                        <label class="text-x-black font-x-thin text-base">
                            <?php echo e(__('Phone')); ?> (*)
                        </label>
                        <neo-textbox rules="required|phone"
                            errors='{"required": "<?php echo e(__('The phone field is required')); ?>", "phone": "<?php echo e(__('The phone field must be a valid phone number')); ?>"}'
                            type="tel" placeholder="<?php echo e(__('Phone')); ?> (*)" name="phone"
                            value="<?php echo e(old('phone')); ?>"></neo-textbox>
                    </div>
                    <div class="flex flex-col gap-1">
                        <label class="text-x-black font-x-thin text-base">
                            <?php echo e(__('City')); ?> (*)
                        </label>
                        <neo-select rules="required" errors='{"required": "<?php echo e(__('The city field is required')); ?>"}' search
                            placeholder="<?php echo e(__('City')); ?> (*)" name="city">
                            <?php $__currentLoopData = Core::citiesList(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $city): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <neo-select-item value="<?php echo e($city); ?>" <?php echo e($city == old('city') ? 'active' : ''); ?>>
                                    <?php echo e(ucfirst(__($city))); ?>

                                </neo-select-item>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </neo-select>
                    </div>
                    <div class="flex flex-col gap-1">
                        <label class="text-x-black font-x-thin text-base">
                            <?php echo e(__('Zopcode')); ?> (*)
                        </label>
                        <neo-textbox rules="required" errors='{"required": "<?php echo e(__('The zipcode field is required')); ?>"}'
                            type="number" placeholder="<?php echo e(__('Zopcode')); ?> (*)" name="zipcode"
                            value="<?php echo e(old('zipcode')); ?>"></neo-textbox>
                    </div>
                    <div class="flex flex-col gap-1">
                        <label class="text-x-black font-x-thin text-base">
                            <?php echo e(__('Address')); ?> (*)
                        </label>
                        <neo-textbox rules="required" errors='{"required": "<?php echo e(__('The address field is required')); ?>"}'
                            placeholder="<?php echo e(__('Address')); ?> (*)" name="address"
                            value="<?php echo e(old('address')); ?>"></neo-textbox>
                    </div>
                </neo-tab-outlet>
                <neo-tab-outlet name="outlet-3" class="grid grid-cols-1 grid-rows-1 gap-6">
                    <div class="flex flex-col gap-1">
                        <label class="text-x-black font-x-thin text-base">
                            <?php echo e(__('Representative first name')); ?> (*)
                        </label>
                        <neo-textbox rules="required"
                            errors='{"required": "<?php echo e(__('The representative first name field is required')); ?>"}'
                            placeholder="<?php echo e(__('Representative first name')); ?> (*)" name="representative_first_name"
                            value="<?php echo e(old('representative_first_name')); ?>"></neo-textbox>
                    </div>
                    <div class="flex flex-col gap-1">
                        <label class="text-x-black font-x-thin text-base">
                            <?php echo e(__('Representative last name')); ?> (*)
                        </label>
                        <neo-textbox rules="required"
                            errors='{"required": "<?php echo e(__('The representative last name field is required')); ?>"}'
                            placeholder="<?php echo e(__('Representative last name')); ?> (*)" name="representative_last_name"
                            value="<?php echo e(old('representative_last_name')); ?>"></neo-textbox>
                    </div>
                    <div class="flex flex-col gap-1">
                        <label class="text-x-black font-x-thin text-base">
                            <?php echo e(__('Representative email')); ?> (*)
                        </label>
                        <neo-textbox rules="required|email"
                            errors='{"required": "<?php echo e(__('The representative email field is required')); ?>", "email": "<?php echo e(__('The representative email field must be a valid email')); ?>"}'
                            type="email" placeholder="<?php echo e(__('Representative email')); ?> (*)"
                            name="representative_email" value="<?php echo e(old('representative_email')); ?>"></neo-textbox>
                    </div>
                    <div class="flex flex-col gap-1">
                        <label class="text-x-black font-x-thin text-base">
                            <?php echo e(__('Representative phone')); ?> (*)
                        </label>
                        <neo-textbox rules="required|phone"
                            errors='{"required": "<?php echo e(__('The representative phone field is required')); ?>", "phone": "<?php echo e(__('The representative phone field must be a valid phone number')); ?>"}'
                            type="tel" placeholder="<?php echo e(__('Representative phone')); ?> (*)"
                            name="representative_phone" value="<?php echo e(old('representative_phone')); ?>"></neo-textbox>
                    </div>
                </neo-tab-outlet>
                <div class="w-full flex flex-wrap gap-6">
                    <neo-button outline type="button" id="prev" style="display: none"
                        class="w-max me-auto outline outline-1 -outline-offset-1 outline-x-prime px-10 text-base lg:text-lg font-x-huge text-x-prime hover:outline-x-acent hover:text-x-white hover:bg-x-acent focus:outline-x-acent focus:text-x-white focus:bg-x-acent focus-within:outline-x-acent focus-within:text-x-white focus-within:bg-x-acent">
                        <span><?php echo e(__('Prev')); ?></span>
                    </neo-button>
                    <neo-button id="save" style="display: none"
                        class="w-max px-10 ms-auto text-base lg:text-lg font-x-huge text-x-white bg-x-prime hover:bg-x-acent focus:bg-x-acent focus-within:bg-x-acent">
                        <span><?php echo e(__('Save')); ?></span>
                    </neo-button>
                    <neo-button outline type="button" id="next"
                        class="w-max ms-auto outline outline-1 -outline-offset-1 outline-x-prime px-10 text-base lg:text-lg font-x-huge text-x-prime hover:outline-x-acent hover:text-x-white hover:bg-x-acent focus:outline-x-acent focus:text-x-white focus:bg-x-acent focus-within:outline-x-acent focus-within:text-x-white focus-within:bg-x-acent">
                        <span><?php echo e(__('Next')); ?></span>
                    </neo-button>
                </div>
            </div>
        </neo-tab-wrapper>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('shared.core.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH P:\php\auto\admin\resources\views/company/store.blade.php ENDPATH**/ ?>