
<?php $__env->startSection('title', __('Recoveries list')); ?>


<?php $__env->startSection('meta'); ?>
    <meta name="routes" content='<?php echo json_encode([
        'filter' => route('actions.recoveries.search'),
        'entire' => route('actions.recoveries.filter'),
        'patch' => route('views.recoveries.patch', 'XXX'),
    ]); ?>' />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="p-6 bg-x-white rounded-x-thin shadow-x-core">
        <neo-datavisualizer print search filter download title="<?php echo e(__('Recoveries list')); ?>">
            <neo-switch slot="start" id="filter" active></neo-switch>
            <?php echo $__env->make('shared.page.print', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </neo-datavisualizer>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('js/recovery/index.min.js')); ?>?v=<?php echo e(env('APP_VERSION')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('shared.core.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH P:\php\auto\admin\resources\views/recovery/index.blade.php ENDPATH**/ ?>