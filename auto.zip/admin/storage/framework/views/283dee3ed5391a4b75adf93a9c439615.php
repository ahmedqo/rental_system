<?php $__env->startSection('title', __('Login')); ?>

<?php $__env->startSection('content'); ?>
    <div style="background-image: url(<?php echo e(asset('img/bg-login.webp')); ?>?v=<?php echo e(env('APP_VERSION')); ?>)"
        alt="<?php echo e(env('APP_NAME')); ?> login background image"
        class="block bg-center bg-cover bg-no-repeat fixed w-full h-[100dvh] inset-0 z-[-1] lg:w-1/2 lg:relative">
        <div class="absolute inset-0 w-full h-full bg-x-black bg-opacity-30 backdrop-blur-sm"></div>
    </div>
    <div class="w-full flex justify-center items-center p-4 lg:w-1/2">
        <div class="w-full lg:w-2/3 flex flex-col gap-4">
            <a href="<?php echo e(route('views.login.index')); ?>" class="block w-36 mx-auto" aria-label="login_page_link">
                <img src="<?php echo e(asset('img/logo.webp')); ?>?v=<?php echo e(env('APP_VERSION')); ?>" alt="<?php echo e(env('APP_NAME')); ?> logo image"
                    class="block w-full" width="916" height="516" loading="lazy" />
            </a>
            <form validate action="<?php echo e(route('actions.login.index')); ?>" method="POST"
                class="w-full flex flex-col gap-6 p-6 bg-x-white rounded-x-thin shadow-x-core">
                <?php echo csrf_field(); ?>
                <div class="flex flex-col gap-1">
                    <label class="text-x-black font-x-thin text-base">
                        <?php echo e(__('Email')); ?> (*)
                    </label>
                    <neo-textbox rules="required|email"
                        errors='{"required": "<?php echo e(__('The email field is required')); ?>", "email": "<?php echo e(__('The email field must be a valid email')); ?>"}'
                        type="email" placeholder="<?php echo e(__('Email')); ?> (*)" name="email"
                        value="<?php echo e(old('email')); ?>"></neo-textbox>
                </div>
                <div class="flex flex-col gap-1">
                    <label class="text-x-black font-x-thin text-base">
                        <?php echo e(__('Password')); ?> (*)
                    </label>
                    <neo-password rules="required" errors='{"required": "<?php echo e(__('The password field is required')); ?>"}'
                        placeholder="<?php echo e(__('Password')); ?> (*)" name="password"
                        value="<?php echo e(old('password')); ?>"></neo-password>
                </div>
                <neo-button
                    class="w-full text-base lg:text-lg font-x-huge text-x-white bg-x-prime hover:bg-x-acent focus:bg-x-acent focus-within:bg-x-acent">
                    <span><?php echo e(__('Login')); ?></span>
                </neo-button>
                <a href="<?php echo e(route('views.blank.index')); ?>" aria-label="forgot_page_link"
                    class="block -mt-2 w-max mx-auto outline-none text-x-acent font-x-huge text-sm hover:text-x-prime focus:text-x-prime focus-within:text-x-prime">
                    <?php echo e(__('Forgot your password?')); ?>

                </a>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('shared.auth.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH P:\php\auto\admin\resources\views/auth/login.blade.php ENDPATH**/ ?>