<?php $__env->startSection('title', __('Page not found')); ?>

<?php $__env->startSection('content'); ?>
    <img src="<?php echo e(asset('img/bg-404.webp')); ?>?v=<?php echo e(env('APP_VERSION')); ?>" alt="<?php echo e(env('APP_NAME')); ?> error 404 image"
        loading="lazy" width="100%" height="auto" class="block w-8/12 sm:w-7/12 lg:w-1/3 mx-auto pointer-events-none">
    <h1 class="uppercase font-x-huge text-x-black text-3xl lg:text-4xl text-center">
        <?php echo e(ucfirst(__('Page not found'))); ?>

    </h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('shared.errors.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH P:\php\auto\admin\resources\views/errors/404.blade.php ENDPATH**/ ?>