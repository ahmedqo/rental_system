<div slot="header" id="header-content">
    <?php if(Core::company()): ?>
        <h1 class="text-2xl text-x-black font-x-huge">
            <?php echo e(strtoupper(Core::company('name'))); ?>

        </h1>
    <?php endif; ?>
    <img id="logo"
        src="<?php echo e(Core::company() ? Core::company('Image')->Link : asset('img/logo.png')); ?>?v=<?php echo e(env('APP_VERSION')); ?>" />
</div>
<?php /**PATH P:\php\auto\admin\resources\views/shared/page/head.blade.php ENDPATH**/ ?>