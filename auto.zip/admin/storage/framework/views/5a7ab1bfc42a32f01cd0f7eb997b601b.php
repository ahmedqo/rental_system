<?php $__env->startSection('title', __('Charges list')); ?>


<?php $__env->startSection('meta'); ?>
    <meta name="routes" content='<?php echo json_encode([
        'search' => route('actions.charges.search'),
        'patch' => route('views.charges.patch', 'XXX'),
        'clear' => route('actions.charges.clear', 'XXX'),
        'csrf' => csrf_token(),
    ]); ?>' />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="p-6 bg-x-white rounded-x-thin shadow-x-core">
        <neo-datavisualizer print search filter download title="<?php echo e(__('Charges list')); ?>">
            
            <?php echo $__env->make('shared.page.print', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </neo-datavisualizer>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('js/charge/index.min.js')); ?>?v=<?php echo e(env('APP_VERSION')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('shared.core.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH P:\php\auto\admin\resources\views/charge/index.blade.php ENDPATH**/ ?>