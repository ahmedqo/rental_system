<div slot="footer" id="footer-content">
    <?php if(Core::company()): ?>
        <div>
            <span><?php echo e(__('ICE number')); ?>:</span>
            <span><?php echo e(Core::company('ice_number')); ?></span>
        </div>
        <div>
            <span><?php echo e(__('Decision number')); ?>:</span>
            <span><?php echo e(Core::company('license_number')); ?></span>
        </div>
        <div>
            <span><?php echo e(__('Phone')); ?>:</span>
            <span><?php echo e(Core::company('phone')); ?></span>
        </div>
        <div>
            <span><?php echo e(__('Email')); ?>:</span>
            <span><?php echo e(Core::company('email')); ?></span>
        </div>
        <div>
            <span><?php echo e(__('Address')); ?>:</span>
            <span>
                <?php echo e(ucfirst(Core::company('address')) . ' ' . ucfirst(__(Core::company('city'))) . ' ' . Core::company('zipcode')); ?>

            </span>
        </div>
    <?php endif; ?>
</div>
<?php /**PATH P:\php\auto\admin\resources\views/shared/page/foot.blade.php ENDPATH**/ ?>