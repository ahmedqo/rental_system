<?php $__env->startSection('title', __('Reservations list')); ?>

<?php $__env->startSection('meta'); ?>
    <meta name="routes" content='<?php echo json_encode([
        'filter' => route('actions.reservations.search'),
        'entire' => route('actions.reservations.filter'),
        'patch' => route('views.reservations.patch', 'XXX'),
        'scene' => route('views.reservations.print', 'XXX'),
    ]); ?>' />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="bg-x-white rounded-x-thin shadow-x-core">
        <neo-datavisualizer print search filter download title="<?php echo e(__('Reservations list')); ?>">
            <neo-switch slot="start" id="filter" active></neo-switch>
            
            <?php echo $__env->make('shared.page.print', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </neo-datavisualizer>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('js/reservation/index.min.js')); ?>?v=<?php echo e(env('APP_VERSION')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('shared.core.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH P:\php\auto\admin\resources\views/reservation/index.blade.php ENDPATH**/ ?>