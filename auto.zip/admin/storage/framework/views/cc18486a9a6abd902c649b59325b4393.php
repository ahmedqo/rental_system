<img slot="top" id="backgroun-image"
    src="<?php echo e(Core::company() ? Core::company('Image')->Link : asset('img/logo.png')); ?>?v=<?php echo e(env('APP_VERSION')); ?>" />
<?php echo $__env->make('shared.page.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('shared.page.foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH P:\php\auto\admin\resources\views/shared/page/print.blade.php ENDPATH**/ ?>