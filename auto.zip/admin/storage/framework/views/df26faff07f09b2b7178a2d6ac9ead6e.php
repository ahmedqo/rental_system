
<?php $__env->startSection('title', __('Preview ticket') . ' #' . $data->id); ?>

<?php $__env->startSection('content'); ?>
    <div class="w-full items-start grid grid-rows-1 grid-cols-1 lg:grid-cols-3 gap-6">
        <div class="flex flex-col p-6 bg-x-white rounded-x-thin shadow-x-core">
            <?php if($data->status !== 'closed'): ?>
                <a title="<?php echo e(__('Close')); ?>" href="<?php echo e(route('actions.tickets.close', $data->id)); ?>"
                    aria-label="create_page_link"
                    class="flex text-base px-2 py-1 w-max ms-auto font-x-thin items-center justify-center bg-red-400 outline-none rounded-x-thin text-x-white hover:bg-red-300 focus:bg-red-300 focus-within:bg-red-300">
                    <?php echo e(__('Close ticket')); ?>

                </a>
            <?php endif; ?>
            <div class="grid grid-rows-1 grid-cols-1 gap-6">
                <div class="flex flex-col gap-1">
                    <label class="text-x-black font-x-thin text-base">
                        <?php echo e(__('Reference')); ?>

                    </label>
                    <neo-textbox placeholder="<?php echo e(__('Reference')); ?>" value="<?php echo e($data->reference); ?>" disable></neo-textbox>
                </div>
                <div class="flex flex-col gap-1">
                    <label class="text-x-black font-x-thin text-base">
                        <?php echo e(__('Category')); ?>

                    </label>
                    <neo-textbox placeholder="<?php echo e(__('Category')); ?>" value="<?php echo e(ucfirst(__($data->category))); ?>"
                        disable></neo-textbox>
                </div>
                <div class="flex flex-col gap-1">
                    <label class="text-x-black font-x-thin text-base">
                        <?php echo e(__('Status')); ?>

                    </label>
                    <neo-textbox placeholder="<?php echo e(__('Status')); ?>" value="<?php echo e(ucfirst(__($data->status))); ?>"
                        disable></neo-textbox>
                </div>
                <div class="flex flex-col gap-1">
                    <label class="text-x-black font-x-thin text-base">
                        <?php echo e(__('Date')); ?>

                    </label>
                    <neo-textbox placeholder="<?php echo e(__('Date')); ?>"
                        value="<?php echo e(\Carbon\Carbon::parse($data->created_at)->translatedFormat(Core::setting() ? Core::formatsList(Core::setting('date_format'), 1) : 'Y-m-d' . ' H:i')); ?>"
                        disable></neo-textbox>
                </div>
                <div class="flex flex-col gap-1">
                    <div class="flex flex-col">
                        <label class="text-x-black font-x-thin text-base">
                            <?php echo e(__('Subject')); ?>

                        </label>
                        <neo-textbox placeholder="<?php echo e(__('Subject')); ?>" value="<?php echo e(ucfirst($data->subject)); ?>"
                            disable></neo-textbox>
                    </div>
                </div>
            </div>
        </div>
        <div class="lg:-order-1 lg:col-span-2 flex flex-col p-6 bg-x-white rounded-x-thin shadow-x-core">
            <div class="flex flex-col gap-4">
                <ul class="flex flex-col gap-4 bg-x-light p-6 rounded-x-thin h-[400px] overflow-auto">
                    <?php $__currentLoopData = $data->Comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="flex flex-wrap">
                            <div
                                class="flex gap-2 flex-col w-max min-w-[30%] max-w-[80%] rounded-x-thin bg-x-white px-4 py-2 <?php echo e($comment->target_type == 'App\\Models\\User' ? 'ms-auto' : 'me-auto'); ?>">
                                <p class="text-x-black text-base">
                                    <?php echo e(ucfirst($comment->content)); ?>

                                </p>
                                <div class="w-full h-px bg-x-light"></div>
                                <p class="text-x-black text-xs w-max ms-auto">
                                    <?php echo e(\Carbon\Carbon::parse($comment->created_at)->translatedFormat(Core::setting() ? Core::formatsList(Core::setting('date_format'), 1) : 'Y-m-d')); ?>

                                </p>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
                <?php if($data->status !== 'closed'): ?>
                    <form validate action="<?php echo e(route('actions.tickets.patch', $data->id)); ?>" method="POST" class="w-full">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('patch'); ?>
                        <div class="w-full grid grid-rows-1 grid-cols-1 gap-6">
                            <div class="flex flex-col gap-1">
                                <label class="text-x-black font-x-thin text-base">
                                    <?php echo e(__('Content')); ?> (*)
                                </label>
                                <neo-textarea rules="required"
                                    errors='{"required": "<?php echo e(__('The content field is required')); ?>"}'
                                    placeholder="<?php echo e(__('Content')); ?> (*)" name="content" value="<?php echo e(old('content')); ?>"
                                    rows="2" auto="false">
                                </neo-textarea>
                            </div>
                            <div class="w-full flex flex-wrap gap-6">
                                <neo-button id="save"
                                    class="w-max px-10 ms-auto text-base lg:text-lg font-x-huge text-x-white bg-x-prime hover:bg-x-acent focus:bg-x-acent focus-within:bg-x-acent">
                                    <span><?php echo e(__('Save')); ?></span>
                                </neo-button>
                            </div>
                        </div>
                    </form>
                <?php endif; ?>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('shared.core.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH P:\php\auto\client\resources\views/ticket/scene.blade.php ENDPATH**/ ?>