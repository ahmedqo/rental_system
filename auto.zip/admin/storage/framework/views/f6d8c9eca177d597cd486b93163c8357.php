<?php $__env->startSection('title', __('New restriction')); ?>

<?php $__env->startSection('meta'); ?>
    <meta name="routes" content='<?php echo json_encode([
        'search' => route('actions.clients.search.all'),
    ]); ?>' />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <form validate action="<?php echo e(route('actions.restrictions.store')); ?>" method="POST"
        class="w-full p-6 bg-x-white rounded-x-thin shadow-x-core">
        <?php echo csrf_field(); ?>
        <div class="w-full flex flex-col gap-6">
            <div class="flex flex-col gap-1">
                <label class="text-x-black font-x-thin text-base">
                    <?php echo e(__('Client')); ?> (*)
                </label>
                <neo-autocomplete rules="required" errors='{"required": "<?php echo e(__('The client field is required')); ?>"}'
                    placeholder="<?php echo e(__('Client')); ?> (*)" set-value="id" set-query="name" name="client"
                    value="<?php echo e(old('client')); ?>" query="<?php echo e(old('client_name')); ?>">
                    <input type="hidden" name="client_name" value="<?php echo e(old('client_name')); ?>">
                </neo-autocomplete>
            </div>
            <div class="flex flex-col gap-1">
                <label class="text-x-black font-x-thin text-base">
                    <?php echo e(__('Reasons')); ?>

                </label>
                <neo-textarea placeholder="<?php echo e(__('Reasons')); ?>" name="reasons" value="<?php echo e(old('reasons')); ?>" rows="6">
                </neo-textarea>
            </div>
            <div class="w-full flex flex-wrap gap-6">
                <neo-button id="save"
                    class="w-max px-10 ms-auto text-base lg:text-lg font-x-huge text-x-white bg-x-prime hover:bg-x-acent focus:bg-x-acent focus-within:bg-x-acent">
                    <span><?php echo e(__('Save')); ?></span>
                </neo-button>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('js/restriction/share.min.js')); ?>?v=<?php echo e(env('APP_VERSION')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('shared.core.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH P:\php\auto\client\resources\views/restriction/store.blade.php ENDPATH**/ ?>