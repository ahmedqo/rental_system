<?php $__env->startSection('title', __('Reminders list')); ?>


<?php $__env->startSection('meta'); ?>
    <meta name="routes" content='<?php echo json_encode([
        'search' => route('actions.reminders.search'),
        'patch' => route('views.reminders.patch', 'XXX'),
        'clear' => route('actions.reminders.clear', 'XXX'),
        'csrf' => csrf_token(),
    ]); ?>' />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="bg-x-white rounded-x-thin shadow-x-core">
        <neo-datavisualizer print search filter download title="<?php echo e(__('Reminders list')); ?>">
            
            <?php echo $__env->make('shared.page.print', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </neo-datavisualizer>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('js/reminder/index.min.js')); ?>?v=<?php echo e(env('APP_VERSION')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('shared.core.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH P:\php\auto\admin\resources\views/reminder/index.blade.php ENDPATH**/ ?>