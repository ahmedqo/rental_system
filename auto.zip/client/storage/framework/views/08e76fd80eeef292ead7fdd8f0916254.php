<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>" dir="<?php echo e(Core::lang('ar') ? 'rtl' : 'ltr'); ?>" class="scroll-smooth">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <?php echo $__env->yieldContent('meta'); ?>
    <?php echo $__env->make('shared.base.styles', ['type' => 'admin'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('styles'); ?>
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <?php if(Core::setting()): ?>
        <meta name="core"
            content="<?php echo e(json_encode([
                'read' => route('actions.core.read'),
                'notify' => route('actions.core.notify'),
                'format' => Core::formatsList(Core::setting('date_format'), 0),
                'currency' => Core::setting('currency'),
            ])); ?>">
        <?php
            $colors = Core::themesList(Core::setting('theme_color'));
            \Carbon\Carbon::setLocale(Core::setting('language'));
        ?>
        <style>
            *,
            :root,
            *::after,
            *::before {
                --prime: <?php echo e($colors[0]); ?>;
                --acent: <?php echo e($colors[1]); ?>;
            }
        </style>
    <?php endif; ?>
</head>

<body close class="bg-x-light bg-x-gradient">
    <section id="neo-page-cover">
        <img src="<?php echo e(Core::company() ? Core::company('Image')->Link : asset('img/logo.png')); ?>?v=<?php echo e(env('APP_VERSION')); ?>"
            alt="<?php echo e(env('APP_NAME')); ?> logo image" class="block w-36" width="916" height="516" />
    </section>
    <neo-wrapper class="flex flex-wrap">
        <?php echo $__env->make('shared.core.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <main class="w-full lg:w-0 lg:flex-1 h-[100dvh] overflow-auto">
            <?php echo $__env->make('shared.core.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <div class="p-4 py-8 md:pt-0 container mx-auto">
                <?php echo $__env->yieldContent('content'); ?>
            </div>
        </main>
    </neo-wrapper>
    <neo-toaster horisontal="end" vertical="start" class="full-size"></neo-toaster>
    <?php echo $__env->make('shared.base.scripts', ['type' => 'admin'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('scripts'); ?>
    <script src="<?php echo e(asset('js/notify.min.js')); ?>?v=<?php echo e(env('APP_VERSION')); ?>"></script>
</body>

</html>
<?php /**PATH P:\php\auto\client\resources\views/shared/core/base.blade.php ENDPATH**/ ?>