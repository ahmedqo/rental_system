<?php $__env->startSection('title', __('New reminder')); ?>

<?php $__env->startSection('meta'); ?>
    <meta name="routes" content='<?php echo json_encode([
        'search' => route('actions.vehicles.search'),
    ]); ?>' />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <form validate action="<?php echo e(route('actions.reminders.store')); ?>" method="POST"
        class="w-full p-6 bg-x-white rounded-x-thin shadow-x-core">
        <?php echo csrf_field(); ?>
        <div class="w-full grid grid-rows-1 grid-cols-1 gap-6">
            <div class="flex flex-col gap-1">
                <label class="text-x-black font-x-thin text-base">
                    <?php echo e(__('Vehicle')); ?> (*)
                </label>
                <neo-autocomplete rules="required" errors='{"required": "<?php echo e(__('The vehicle field is required')); ?>"}'
                    placeholder="<?php echo e(__('Vehicle')); ?> (*)" set-value="id" set-query="name" name="vehicle"
                    value="<?php echo e(old('vehicle')); ?>" query="<?php echo e(old('vehicle_name')); ?>">
                    <input type="hidden" name="vehicle_name" value="<?php echo e(old('vehicle_name')); ?>">
                </neo-autocomplete>
            </div>
            <div class="flex flex-col gap-1">
                <label class="text-x-black font-x-thin text-base">
                    <?php echo e(__('Consumable name')); ?> (*)
                </label>
                <neo-select rules="required" errors='{"required": "<?php echo e(__('The consumable name field is required')); ?>"}'
                    search placeholder="<?php echo e(__('Consumable name')); ?> (*)" name="consumable_name">
                    <?php $__currentLoopData = Core::consumablesList(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $group => $list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <neo-select-group label="<?php echo e(ucfirst(__($group))); ?>">
                            <?php $__currentLoopData = $list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consumable): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <neo-select-item value="<?php echo e($consumable); ?>"
                                    <?php echo e($consumable == old('consumable_name') ? 'active' : ''); ?>>
                                    <?php echo e(ucfirst(__($consumable))); ?>

                                </neo-select-item>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </neo-select-group>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </neo-select>
            </div>
            <div class="flex flex-col gap-1">
                <label class="text-x-black font-x-thin text-base">
                    <?php echo e(__('Unit of measurement')); ?> (*)
                </label>
                <neo-select rules="required" errors='{"required": "<?php echo e(__('The unit of measurement field is required')); ?>"}'
                    placeholder="<?php echo e(__('Unit of measurement')); ?> (*)" name="unit_of_measurement">
                    <?php $__currentLoopData = Core::unitsList(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit_of_measurement): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <neo-select-item value="<?php echo e($unit_of_measurement); ?>"
                            <?php echo e($unit_of_measurement == old('unit_of_measurement') ? 'active' : ''); ?>>
                            <?php echo e(ucfirst(__($unit_of_measurement))); ?>

                        </neo-select-item>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </neo-select>
            </div>
            <div class="flex flex-col gap-1">
                <label class="text-x-black font-x-thin text-base">
                    <?php echo e(__('Recurrence amount')); ?> (*)
                </label>
                <neo-textbox rules="required" errors='{"required": "<?php echo e(__('The recurrence amount is required')); ?>"}'
                    type="number" placeholder="<?php echo e(__('Recurrence amount')); ?> (*)" name="recurrence_amount"
                    value="<?php echo e(old('recurrence_amount')); ?>"></neo-textbox>
            </div>
            <div show-unless="unit_of_measurement,mileage" class="flex flex-col gap-1">
                <label class="text-x-black font-x-thin text-base">
                    <?php echo e(__('Reminder date')); ?> (*)
                </label>
                <neo-datepicker rules="required_unless:unit_of_measurement,mileage"
                    errors='{"required_unless": "<?php echo e(__('The reminder date is required')); ?>"}'
                    <?php echo e(!Core::lang('ar') ? 'full-day=3' : ''); ?> placeholder="<?php echo e(__('Reminder date')); ?> (*)"
                    name="reminder_date" format="<?php echo e(Core::formatsList(Core::setting('date_format'), 0)); ?>"
                    value="<?php echo e(old('reminder_date')); ?>"></neo-datepicker>
            </div>
            <div class="flex flex-col gap-1">
                <label class="text-x-black font-x-thin text-base">
                    <?php echo e(__('Threshold value')); ?> (*)
                </label>
                <neo-textbox rules="required" errors='{"required": "<?php echo e(__('The threshold value is required')); ?>"}'
                    type="number" placeholder="<?php echo e(__('Threshold value')); ?> (*)" name="threshold_value"
                    value="<?php echo e(old('threshold_value')); ?>"></neo-textbox>
            </div>
            <div class="w-full flex flex-wrap gap-6">
                <neo-button id="save"
                    class="w-max px-6 ms-auto text-base lg:text-lg font-x-huge text-x-white bg-x-prime hover:bg-x-acent focus:bg-x-acent focus-within:bg-x-acent">
                    <span><?php echo e(__('Save')); ?></span>
                </neo-button>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('js/reminder/share.min.js')); ?>?v=<?php echo e(env('APP_VERSION')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('shared.core.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH P:\php\auto\client\resources\views/reminder/store.blade.php ENDPATH**/ ?>