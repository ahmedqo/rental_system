<?php $__env->startSection('title', __('New charge')); ?>

<?php $__env->startSection('meta'); ?>
    <meta name="routes" content='<?php echo json_encode([
        'search' => route('actions.vehicles.search'),
    
        'storeVehicle' => route('actions.vehicles.store'),
    ]); ?>' />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <form validate action="<?php echo e(route('actions.charges.store')); ?>" method="POST"
        class="w-full p-6 bg-x-white rounded-x-thin shadow-x-core">
        <?php echo csrf_field(); ?>
        <div class="w-full grid grid-rows-1 grid-cols-1 gap-6">
            <div class="flex flex-col gap-1">
                <label class="text-x-black font-x-thin text-base">
                    <?php echo e(__('Vehicle')); ?> (*)
                </label>
                <neo-autocomplete rules="required" errors='{"required": "<?php echo e(__('The vehicle field is required')); ?>"}'
                    placeholder="<?php echo e(__('Vehicle')); ?> (*)" set-value="id" set-query="name" name="vehicle"
                    value="<?php echo e(old('vehicle')); ?>" query="<?php echo e(old('vehicle_name')); ?>">
                    <input type="hidden" name="vehicle_name" value="<?php echo e(old('vehicle_name')); ?>">
                </neo-autocomplete>
            </div>
            <div class="flex flex-col gap-1">
                <label class="text-x-black font-x-thin text-base">
                    <?php echo e(__('Name')); ?> (*)
                </label>
                <neo-textbox rules="required" errors='{"required": "<?php echo e(__('The name field is required')); ?>"}'
                    placeholder="<?php echo e(__('Name')); ?> (*)" name="name" value="<?php echo e(old('name')); ?>"></neo-textbox>
            </div>
            <div class="flex flex-col gap-1">
                <label class="text-x-black font-x-thin text-base">
                    <?php echo e(__('Cost')); ?> (*)
                </label>
                <neo-textbox rules="required" errors='{"required": "<?php echo e(__('The cost field is required')); ?>"}'
                    placeholder="<?php echo e(__('Cost')); ?> (*)" name="cost" value="<?php echo e(old('cost')); ?>"></neo-textbox>
            </div>
            <div class="flex flex-col gap-1">
                <label class="text-x-black font-x-thin text-base">
                    <?php echo e(__('Details')); ?>

                </label>
                <neo-textarea placeholder="<?php echo e(__('Details')); ?>" name="details" value="<?php echo e(old('details')); ?>"
                    rows="4">
                </neo-textarea>
            </div>
            <div class="w-full flex flex-wrap gap-6">
                <neo-button id="save"
                    class="w-max px-6 ms-auto text-base lg:text-lg font-x-huge text-x-white bg-x-prime hover:bg-x-acent focus:bg-x-acent focus-within:bg-x-acent">
                    <span><?php echo e(__('Save')); ?></span>
                </neo-button>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('js/charge/share.min.js')); ?>?v=<?php echo e(env('APP_VERSION')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('shared.core.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH P:\php\auto\client\resources\views/charge/store.blade.php ENDPATH**/ ?>