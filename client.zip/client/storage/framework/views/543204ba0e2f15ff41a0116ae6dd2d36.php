<div slot="header" id="header-content">
    
    <span></span>
    <div class="flex flex-col w-max items-cente gap-1">
        <img id="logo"
            src="<?php echo e(Core::company() ? Core::company('Image')->Link : asset('img/logo.png')); ?>?v=<?php echo e(env('APP_VERSION')); ?>" />
        <?php if(Core::company()): ?>
            <h1>
                <?php echo e(strtoupper(Core::company('name'))); ?>

            </h1>
        <?php endif; ?>
    </div>
    <span></span>
</div>
<?php /**PATH P:\php\auto\client\resources\views/shared/page/head.blade.php ENDPATH**/ ?>