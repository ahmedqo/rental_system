<link rel="stylesheet" href="<?php echo e(asset('css/index.min.css')); ?>?v=<?php echo e(env('APP_VERSION')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('css/app.min.css')); ?>?v=<?php echo e(env('APP_VERSION')); ?>" />
<?php /**PATH P:\php\auto\client\resources\views/shared/base/styles.blade.php ENDPATH**/ ?>