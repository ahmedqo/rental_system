<img slot="top" id="backgroun-image"
    src="<?php echo e(Core::company() ? Core::company('Image')->Link : asset('img/logo.png')); ?>?v=<?php echo e(env('APP_VERSION')); ?>" />
<?php if(Core::preference()): ?>
    <?php
        $colors = Core::themesList(Core::preference('theme_color'));
    ?>
    <style slot="styles">
        *,
        :root,
        *::after,
        *::before {
            --p-prime: <?php echo e($colors[0]); ?>;
            --p-acent: <?php echo e($colors[1]); ?>;
        }
    </style>
<?php endif; ?>
<?php echo $__env->make('shared.page.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('shared.page.foot', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH P:\php\auto\client\resources\views/shared/page/print.blade.php ENDPATH**/ ?>