<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>" dir="<?php echo e(Core::lang('ar') ? 'rtl' : 'ltr'); ?>" class="scroll-smooth">

<head>
    <meta charset="UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <?php echo $__env->make('shared.base.styles', ['type' => 'guest'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('styles'); ?>
    <title><?php echo $__env->yieldContent('title'); ?></title>
</head>

<body close class="bg-[#fcfcfc]">
    <section id="neo-page-cover">
        <img src="<?php echo e(asset('img/logo.webp')); ?>?v=<?php echo e(env('APP_VERSION')); ?>" alt="<?php echo e(env('APP_NAME')); ?> logo image"
            class="block w-36" width="916" height="516" loading="lazy" />
    </section>
    <neo-wrapper class="flex flex-wrap">
        <main class="w-full p-4 container mx-auto flex flex-col gap-4 h-[100dvh]">
            <header class="w-full flex justify-center">
                <a href="<?php echo e(url('/')); ?>" class="block w-36 mx-auto" aria-label="home_page_link">
                    <img src="<?php echo e(asset('img/logo.webp')); ?>?v=<?php echo e(env('APP_VERSION')); ?>"
                        alt="<?php echo e(env('APP_NAME')); ?> logo image" class="block w-full" width="916" height="516"
                        loading="lazy" />
                </a>
            </header>
            <section class="w-full flex flex-col gap-4 flex-1 items-center justify-center">
                <?php echo $__env->yieldContent('content'); ?>
            </section>
        </main>
    </neo-wrapper>
    <neo-toaster horisontal="center" vertical="end"></neo-toaster>
    <?php echo $__env->make('shared.base.scripts', ['type' => 'guest'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php echo $__env->yieldContent('scripts'); ?>
</body>

</html>
<?php /**PATH P:\php\auto\client\resources\views/shared/errors/base.blade.php ENDPATH**/ ?>