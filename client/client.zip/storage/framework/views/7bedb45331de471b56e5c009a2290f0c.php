
<?php $__env->startSection('title', __('New ticket')); ?>

<?php $__env->startSection('content'); ?>
    <form validate action="<?php echo e(route('actions.tickets.store')); ?>" method="POST"
        class="w-full p-6 bg-x-white rounded-x-thin shadow-x-core">
        <?php echo csrf_field(); ?>
        <div class="w-full grid grid-rows-1 grid-cols-1 gap-6">
            <div class="flex flex-col gap-1">
                <label class="text-x-black font-x-thin text-base">
                    <?php echo e(__('Subject')); ?> (*)
                </label>
                <neo-textbox rules="required" errors='{"required": "<?php echo e(__('The subject field is required')); ?>"}'
                    placeholder="<?php echo e(__('Subject')); ?> (*)" name="subject" value="<?php echo e(old('subject')); ?>">
                </neo-textbox>
            </div>
            <div class="flex flex-col gap-1">
                <label class="text-x-black font-x-thin text-base">
                    <?php echo e(__('Category')); ?> (*)
                </label>
                <neo-select rules="required" errors='{"required": "<?php echo e(__('The category field is required')); ?>"}' search
                    placeholder="<?php echo e(__('Category')); ?> (*)" name="category">
                    <?php $__currentLoopData = Core::categoriesList(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <neo-select-item value="<?php echo e($category); ?>" <?php echo e($category == old('category') ? 'active' : ''); ?>>
                            <?php echo e(ucfirst(__($category))); ?>

                        </neo-select-item>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </neo-select>
            </div>
            <div class="flex flex-col gap-1">
                <label class="text-x-black font-x-thin text-base">
                    <?php echo e(__('Content')); ?> (*)
                </label>
                <neo-textarea rules="required" errors='{"required": "<?php echo e(__('The content field is required')); ?>"}'
                    placeholder="<?php echo e(__('Content')); ?> (*)" name="content" value="<?php echo e(old('content')); ?>" rows="5">
                </neo-textarea>
            </div>
            <div class="w-full flex flex-wrap gap-6">
                <neo-button id="save"
                    class="w-max px-6 ms-auto text-base lg:text-lg font-x-huge text-x-white bg-x-prime hover:bg-x-acent focus:bg-x-acent focus-within:bg-x-acent">
                    <span><?php echo e(__('Save')); ?></span>
                </neo-button>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('shared.core.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH P:\php\auto\client\resources\views/ticket/store.blade.php ENDPATH**/ ?>