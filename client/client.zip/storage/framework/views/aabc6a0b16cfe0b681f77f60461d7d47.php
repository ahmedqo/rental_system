
<?php $__env->startSection('title', __('Edit preferences')); ?>

<?php $__env->startSection('content'); ?>
    <form validate action="<?php echo e(route('actions.preferences.patch')); ?>" method="POST"
        class="w-full p-6 bg-x-white rounded-x-thin shadow-x-core">
        <?php echo csrf_field(); ?>
        <?php echo method_field('patch'); ?>
        <div class="w-full grid grid-rows-1 grid-cols-1 gap-6">
            <div class="flex flex-col gap-1">
                <label class="text-x-black font-x-thin text-base">
                    <?php echo e(__('Report frequency')); ?> (*)
                </label>
                <neo-select rules="required" errors='{"required": "<?php echo e(__('The report frequency field is required')); ?>"}'
                    placeholder="<?php echo e(__('Report frequency')); ?> (*)" name="report_frequency">
                    <?php $__currentLoopData = Core::periodsList(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $report_frequency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <neo-select-item value="<?php echo e($report_frequency); ?>"
                            <?php echo e($report_frequency == old('report_frequency', $data->report_frequency) ? 'active' : ''); ?>>
                            <?php echo e(ucfirst(__($report_frequency))); ?>

                        </neo-select-item>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </neo-select>
            </div>
            <div class="flex flex-col gap-1">
                <label class="text-x-black font-x-thin text-base">
                    <?php echo e(__('Currency')); ?> (*)
                </label>
                <neo-select rules="required" errors='{"required": "<?php echo e(__('The currency field is required')); ?>"}'
                    placeholder="<?php echo e(__('Currency')); ?> (*)" name="currency" disable class="hide-icon">
                    <?php $__currentLoopData = Core::currenciesList(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cur => $currency): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <neo-select-item value="<?php echo e($cur); ?>"
                            text="<?php echo e(strtoupper($cur)); ?> - <?php echo e(ucfirst(__($currency))); ?>"
                            <?php echo e($cur == old('currency', $data->currency) ? 'active' : ''); ?> class="flex items-center gap-1">
                            <span class="font-x-thin"><?php echo e(strtoupper($cur)); ?></span>
                            <span>-</span>
                            <span><?php echo e(ucfirst(__($currency))); ?></span>
                        </neo-select-item>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </neo-select>
            </div>
            <div class="flex flex-col gap-1">
                <label class="text-x-black font-x-thin text-base">
                    <?php echo e(__('Language')); ?> (*)
                </label>
                <neo-select rules="required" errors='{"required": "<?php echo e(__('The language field is required')); ?>"}'
                    placeholder="<?php echo e(__('Language')); ?> (*)" name="language">
                    <?php $__currentLoopData = Core::languagesList(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lang => $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <neo-select-item value="<?php echo e($lang); ?>"
                            <?php echo e($lang == old('language', $data->language) ? 'active' : ''); ?>

                            class="flex flex-wrap gap-2 items-center">
                            <img src="<?php echo e(asset('lang/' . $lang . '.png')); ?>?v=<?php echo e(env('APP_VERSION')); ?>" alt="english flag"
                                class="block w-10 h-6 object-contain" />
                            <?php echo e(ucfirst(__($language))); ?>

                        </neo-select-item>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </neo-select>
            </div>
            <div class="flex flex-col gap-1">
                <label class="text-x-black font-x-thin text-base">
                    <?php echo e(__('Date format')); ?> (*)
                </label>
                <neo-select rules="required" errors='{"required": "<?php echo e(__('The date format field is required')); ?>"}'
                    placeholder="<?php echo e(__('Date format')); ?> (*)" name="date_format">
                    <?php $__currentLoopData = Core::formatsList(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $date_format => $formats): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <neo-select-item value="<?php echo e($date_format); ?>" text="<?php echo e(ucfirst(__($date_format))); ?>"
                            <?php echo e($date_format == old('date_format', $data->date_format) ? 'active' : ''); ?>>
                            <span><?php echo e(ucfirst(__($date_format))); ?></span><span class="mx-1"></span><span
                                class="text-x-shade">(<?php echo e(\Carbon\Carbon::now()->translatedFormat($formats[1])); ?>)</span>
                        </neo-select-item>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </neo-select>
            </div>
            <div class="flex flex-col gap-1">
                <label class="text-x-black font-x-thin text-base">
                    <?php echo e(__('Theme color')); ?> (*)
                </label>
                <neo-select rules="required" errors='{"required": "<?php echo e(__('The theme color field is required')); ?>"}'
                    placeholder="<?php echo e(__('Theme color')); ?> (*)" name="theme_color">
                    <?php $__currentLoopData = Core::themesList(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $theme_color => $colors): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <neo-select-item value="<?php echo e($theme_color); ?>"
                            <?php echo e($theme_color == old('theme_color', $data->theme_color) ? 'active' : ''); ?>

                            class="flex flex-wrap gap-2 items-center">
                            <div class="w-max flex items-center">
                                <span
                                    class="block w-8 rounded-full border-2 border-x-x-white border-y-x-white aspect-square relative z-[1]"
                                    style="background-color: rgb(<?php echo e($colors[0]); ?>)"></span>
                                <span
                                    class="-ms-4 block w-7 rounded-full border-2 border-x-x-white border-y-x-white aspect-square"
                                    style="background-color: rgb(<?php echo e($colors[1]); ?>)"></span>
                            </div>
                            <?php echo e(ucfirst(__($theme_color))); ?>

                        </neo-select-item>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </neo-select>
            </div>
            <div class="w-full flex flex-wrap gap-6">
                <neo-button id="save"
                    class="w-max px-6 ms-auto text-base lg:text-lg font-x-huge text-x-white bg-x-prime hover:bg-x-acent focus:bg-x-acent focus-within:bg-x-acent">
                    <span><?php echo e(__('Save')); ?></span>
                </neo-button>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('shared.core.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH P:\php\auto\client\resources\views/preference/patch.blade.php ENDPATH**/ ?>