<?php $__env->startSection('title', __('New vehicle')); ?>

<?php $__env->startSection('content'); ?>
    <form validate action="<?php echo e(route('actions.vehicles.store')); ?>" method="POST" class="w-full">
        <?php echo csrf_field(); ?>
        <neo-tab-wrapper outlet="outlet-1" class="w-full flex flex-col gap-6">
            <div class="flex flex-wrap items-center justify-between gap-2 lg:gap-6 relative isolate">
                <div class="absolute h-1 w-full bg-x-white left-0 right-0 top-1/2 -translate-y-1/2 z-[-1]">
                    <div id="track" class="absolute h-full top-0 bottom-0 w-0 bg-x-prime"></div>
                </div>
                <?php for($i = 1; $i <= 7; $i++): ?>
                    <neo-tab-trigger tabindex="0" slot="triggers" for="outlet-<?php echo e($i); ?>"
                        class="flex w-8 h-8 aspect-square items-center justify-center text-lg font-x-thin text-x-black bg-x-white rounded-x-thin outline-none hover:bg-x-acent hover:text-x-white focus:bg-x-acent focus:text-x-white">
                        <span><?php echo e($i); ?></span>
                        <svg class="hidden w-6 h-6 pointer-events-none text-x-prime" fill="currentcolor"
                            viewBox="0 -960 960 960">
                            <path
                                d="M261-167-5-433l95-95 172 171 95 95-96 95Zm240-32L232-467l97-95 172 171 369-369 96 96-465 465Zm-7-280-95-95 186-186 95 95-186 186Z" />
                        </svg>
                    </neo-tab-trigger>
                <?php endfor; ?>
            </div>
            <div class="w-full flex flex-col gap-6 p-6 bg-x-white rounded-x-thin shadow-x-core">
                <neo-tab-outlet name="outlet-1" class="grid grid-cols-1 grid-rows-1 gap-6">
                    <div class="flex flex-col gap-1">
                        <label class="text-x-black font-x-thin text-base">
                            <?php echo e(__('Registration type')); ?> (*)
                        </label>
                        <neo-select rules="required"
                            errors='{"required": "<?php echo e(__('The registration type field is required')); ?>"}'
                            placeholder="<?php echo e(__('Registration type')); ?> (*)" name="registration_type">
                            <?php $__currentLoopData = Core::registrationList(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registration_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <neo-select-item value="<?php echo e($registration_type); ?>"
                                    <?php echo e($registration_type == old('registration_type', 'vehicle') ? 'active' : ''); ?>>
                                    <?php echo e(ucfirst(__($registration_type))); ?>

                                </neo-select-item>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </neo-select>
                    </div>
                    <div show-if="registration_type,WW" class="flex flex-col gap-1">
                        <label class="text-x-black font-x-thin text-base">
                            <?php echo e(__('Registration number')); ?> (*)
                        </label>
                        <div class="w-full flex gap-[2px]">
                            <neo-textbox disable class="flex-[1]" name="registration_ww_part_1"
                                value="WW"></neo-textbox>
                            <neo-textbox rules="required_if:registration_type,WW"
                                errors='{"required_if": "<?php echo e(__('The registration number part 2 field is required')); ?>"}'
                                class="flex-[2]" placeholder="XXXXX (*)" name="registration_ww_part_2"
                                value="<?php echo e(old('registration_ww_part_2')); ?>"></neo-textbox>
                        </div>
                    </div>
                    <div show-if="registration_type,vehicle" class="flex flex-col gap-1">
                        <label class="text-x-black font-x-thin text-base">
                            <?php echo e(__('Registration number')); ?> (*)
                        </label>
                        <div class="w-full flex gap-[2px]">
                            <neo-textbox rules="required_if:registration_type,vehicle"
                                errors='{"required_if": "<?php echo e(__('The registration number part 1 field is required')); ?>"}'
                                class="flex-[1]" placeholder="XXXXX (*)" name="registration_vehicle_part_1"
                                value="<?php echo e(old('registration_vehicle_part_1')); ?>"></neo-textbox>
                            <neo-select rules="required_if:registration_type,vehicle"
                                errors='{"required_if": "<?php echo e(__('The registration number part 2 field is required')); ?>"}'
                                class="flex-[1]" placeholder="X (*)" name="registration_vehicle_part_2">
                                <?php $__currentLoopData = Core::alphaList(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $registration_part): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <neo-select-item value="<?php echo e($registration_part); ?>"
                                        <?php echo e($registration_part == old('registration_vehicle_part_2') ? 'active' : ''); ?>>
                                        <?php echo e(ucfirst(__($registration_part))); ?>

                                    </neo-select-item>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </neo-select>
                            <neo-textbox rules="required_if:registration_type,vehicle"
                                errors='{"required_if": "<?php echo e(__('The registration number part 3 field is required')); ?>"}'
                                class="flex-[1]" placeholder="XX (*)" name="registration_vehicle_part_3"
                                value="<?php echo e(old('registration_vehicle_part_3')); ?>"></neo-textbox>
                        </div>
                    </div>
                    <div class="flex flex-col gap-1">
                        <label class="text-x-black font-x-thin text-base">
                            <?php echo e(__('Registration date')); ?> (*)
                        </label>
                        <neo-datepicker rules="required"
                            errors='{"required": "<?php echo e(__('The registration date field is required')); ?>"}'
                            <?php echo e(!Core::lang('ar') ? 'full-day=3' : ''); ?> placeholder="<?php echo e(__('Registration date')); ?> (*)"
                            name="registration_date" format="<?php echo e(Core::formatsList(Core::setting('date_format'), 0)); ?>"
                            value="<?php echo e(old('registration_date')); ?>"></neo-datepicker>
                    </div>
                </neo-tab-outlet>
                <neo-tab-outlet name="outlet-2" class="grid grid-cols-1 grid-rows-1 gap-6">
                    <div class="flex flex-col gap-1">
                        <label class="text-x-black font-x-thin text-base">
                            <?php echo e(__('Brand')); ?> (*)
                        </label>
                        <neo-autocomplete rules="required" errors='{"required": "<?php echo e(__('The brand field is required')); ?>"}'
                            handfree placeholder="<?php echo e(__('Brand')); ?> (*)" name="brand" value="<?php echo e(old('brand')); ?>"
                            query="<?php echo e(old('brand')); ?>">
                        </neo-autocomplete>
                    </div>
                    <div class="flex flex-col gap-1">
                        <label class="text-x-black font-x-thin text-base">
                            <?php echo e(__('Model')); ?> (*)
                        </label>
                        <neo-autocomplete rules="required" errors='{"required": "<?php echo e(__('The model field is required')); ?>"}'
                            handfree placeholder="<?php echo e(__('Model')); ?> (*)" name="model" value="<?php echo e(old('model')); ?>"
                            query="<?php echo e(old('model')); ?>">
                        </neo-autocomplete>
                    </div>
                    <div class="flex flex-col gap-1">
                        <label class="text-x-black font-x-thin text-base">
                            <?php echo e(__('Year')); ?> (*)
                        </label>
                        <neo-select rules="required" errors='{"required": "<?php echo e(__('The year field is required')); ?>"}'
                            placeholder="<?php echo e(__('Year')); ?> (*)" name="year">
                            <?php for($year = date('Y') - 4; $year <= date('Y'); $year++): ?>
                                <neo-select-item value="<?php echo e($year); ?>" <?php echo e($year == old('year') ? 'active' : ''); ?>>
                                    <?php echo e($year); ?>

                                </neo-select-item>
                            <?php endfor; ?>
                        </neo-select>
                    </div>
                </neo-tab-outlet>
                <neo-tab-outlet name="outlet-3" class="grid grid-cols-1 grid-rows-1 gap-6">
                    <div class="flex flex-col gap-1">
                        <label class="text-x-black font-x-thin text-base">
                            <?php echo e(__('Passenger capacity')); ?> (*)
                        </label>
                        <neo-textbox rules="required"
                            errors='{"required": "<?php echo e(__('The passenger capacity field is required')); ?>"}' type="number"
                            placeholder="<?php echo e(__('Passenger capacity')); ?> (*)" name="passenger_capacity"
                            value="<?php echo e(old('passenger_capacity')); ?>"></neo-textbox>
                    </div>
                    <div class="flex flex-col gap-1">
                        <label class="text-x-black font-x-thin text-base">
                            <?php echo e(__('Cargo capacity')); ?> (*)
                        </label>
                        <neo-textbox rules="required"
                            errors='{"required": "<?php echo e(__('The cargo capacity field is required')); ?>"}' type="number"
                            placeholder="<?php echo e(__('Cargo capacity')); ?> (*)" name="cargo_capacity"
                            value="<?php echo e(old('cargo_capacity')); ?>"></neo-textbox>
                    </div>
                    <div class="flex flex-col gap-1">
                        <label class="text-x-black font-x-thin text-base">
                            <?php echo e(__('Number of doors')); ?> (*)
                        </label>
                        <neo-textbox rules="required"
                            errors='{"required": "<?php echo e(__('The number of doors field is required')); ?>"}' type="number"
                            placeholder="<?php echo e(__('Number of doors')); ?> (*)" name="number_of_doors"
                            value="<?php echo e(old('number_of_doors')); ?>"></neo-textbox>
                    </div>
                </neo-tab-outlet>
                <neo-tab-outlet name="outlet-4" class="grid grid-cols-1 grid-rows-1 gap-6">
                    <div class="flex flex-col gap-1">
                        <label class="text-x-black font-x-thin text-base">
                            <?php echo e(__('Transmission type')); ?> (*)
                        </label>
                        <neo-select rules="required"
                            errors='{"required": "<?php echo e(__('The transmission type field is required')); ?>"}'
                            placeholder="<?php echo e(__('Transmission type')); ?> (*)" name="transmission_type">
                            <?php $__currentLoopData = Core::transmissionsList(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $transmission_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <neo-select-item value="<?php echo e($transmission_type); ?>"
                                    <?php echo e($transmission_type == old('transmission_type') ? 'active' : ''); ?>>
                                    <?php echo e(ucfirst(__($transmission_type))); ?>

                                </neo-select-item>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </neo-select>
                    </div>
                    <div class="flex flex-col gap-1">
                        <label class="text-x-black font-x-thin text-base">
                            <?php echo e(__('Mileage')); ?> (*)
                        </label>
                        <neo-textbox rules="required" errors='{"required": "<?php echo e(__('The mileage field is required')); ?>"}'
                            type="number" placeholder="<?php echo e(__('Mileage')); ?> (*)" name="mileage"
                            value="<?php echo e(old('mileage')); ?>"></neo-textbox>
                    </div>
                    <div class="flex flex-col gap-1">
                        <label class="text-x-black font-x-thin text-base">
                            <?php echo e(__('Daily rate')); ?> (*)
                        </label>
                        <neo-textbox rules="required"
                            errors='{"required": "<?php echo e(__('The daily rate field is required')); ?>"}' type="number"
                            placeholder="<?php echo e(__('Daily rate')); ?> (*)" name="daily_rate"
                            value="<?php echo e(old('daily_rate')); ?>"></neo-textbox>
                    </div>
                </neo-tab-outlet>
                <neo-tab-outlet name="outlet-5" class="grid grid-cols-1 grid-rows-1 gap-6">
                    <div class="flex flex-col gap-1">
                        <label class="text-x-black font-x-thin text-base">
                            <?php echo e(__('Fuel type')); ?> (*)
                        </label>
                        <neo-select rules="required" errors='{"required": "<?php echo e(__('The fuel type field is required')); ?>"}'
                            placeholder="<?php echo e(__('Fuel type')); ?> (*)" name="fuel_type">
                            <?php $__currentLoopData = Core::fuelsList(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fuel_type): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <neo-select-item value="<?php echo e($fuel_type); ?>"
                                    <?php echo e($fuel_type == old('fuel_type') ? 'active' : ''); ?>>
                                    <?php echo e(ucfirst(__($fuel_type))); ?>

                                </neo-select-item>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </neo-select>
                    </div>
                    <div class="flex flex-col gap-1">
                        <label class="text-x-black font-x-thin text-base">
                            <?php echo e(__('Horsepower')); ?> (*)
                        </label>
                        <neo-select rules="required"
                            errors='{"required": "<?php echo e(__('The horsepower field is required')); ?>"}'
                            placeholder="<?php echo e(__('Horsepower')); ?> (*)" name="horsepower">
                            <?php $__currentLoopData = Core::horsepowersList(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $horsepower): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <neo-select-item value="<?php echo e($horsepower); ?>"
                                    <?php echo e($horsepower == old('horsepower') ? 'active' : ''); ?>>
                                    <?php echo e(ucfirst(__($horsepower))); ?>

                                </neo-select-item>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </neo-select>
                    </div>
                    <div class="flex flex-col gap-1">
                        <label class="text-x-black font-x-thin text-base">
                            <?php echo e(__('Horsepower tax')); ?> (*)
                        </label>
                        <neo-textbox rules="required"
                            errors='{"required": "<?php echo e(__('The horsepower tax field is required')); ?>"}' type="number"
                            placeholder="<?php echo e(__('Horsepower tax')); ?> (*)" name="horsepower_tax"
                            value="<?php echo e(old('horsepower_tax')); ?>"></neo-textbox>
                    </div>
                </neo-tab-outlet>
                <neo-tab-outlet name="outlet-6" class="grid grid-cols-1 grid-rows-1 gap-6">
                    <div class="flex flex-col gap-1">
                        <label class="text-x-black font-x-thin text-base">
                            <?php echo e(__('Loan amount')); ?>

                        </label>
                        <neo-textbox type="number" placeholder="<?php echo e(__('Loan amount')); ?>" name="loan_amount"
                            value="<?php echo e(old('loan_amount')); ?>"></neo-textbox>
                    </div>
                    <div class="flex flex-col gap-1">
                        <label class="required-label text-x-black font-x-thin text-base">
                            <?php echo e(__('Monthly installment')); ?>

                        </label>
                        <neo-textbox rules="required_with:loan_amount"
                            errors='{"required_with": "<?php echo e(__('The monthly installment field is required')); ?>"}'
                            type="number" placeholder="<?php echo e(__('Monthly installment')); ?>" name="monthly_installment"
                            class="required-input" value="<?php echo e(old('monthly_installment')); ?>"></neo-textbox>
                    </div>
                    <div class="flex flex-col gap-1">
                        <label class="required-label text-x-black font-x-thin text-base">
                            <?php echo e(__('Loan issued at')); ?>

                        </label>
                        <neo-datepicker rules="required_with:loan_amount"
                            errors='{"required_with": "<?php echo e(__('The loan issued at field is required')); ?>"}'
                            <?php echo e(!Core::lang('ar') ? 'full-day=3' : ''); ?> placeholder="<?php echo e(__('Loan issued at')); ?>"
                            class="required-input" name="loan_issued_at"
                            format="<?php echo e(Core::formatsList(Core::setting('date_format'), 0)); ?>"
                            value="<?php echo e(old('loan_issued_at')); ?>"></neo-datepicker>
                    </div>
                </neo-tab-outlet>
                <neo-tab-outlet name="outlet-7" class="grid grid-cols-1 grid-rows-1 gap-6">
                    <div class="flex flex-col gap-1">
                        <label class="text-x-black font-x-thin text-base">
                            <?php echo e(__('Insurance company')); ?> (*)
                        </label>
                        <neo-autocomplete rules="required"
                            errors='{"required": "<?php echo e(__('The insurance company field is required')); ?>"}' handfree
                            placeholder="<?php echo e(__('Insurance company')); ?> (*)" name="insurance_company"
                            value="<?php echo e(old('insurance_company')); ?>" query="<?php echo e(old('insurance_company')); ?>">
                        </neo-autocomplete>
                    </div>
                    <div class="flex flex-col gap-1">
                        <label class="text-x-black font-x-thin text-base">
                            <?php echo e(__('Insurance issued at')); ?> (*)
                        </label>
                        <neo-datepicker rules="required"
                            errors='{"required": "<?php echo e(__('The insurance issued at field is required')); ?>"}'
                            <?php echo e(!Core::lang('ar') ? 'full-day=3' : ''); ?>

                            placeholder="<?php echo e(__('Insurance issued at')); ?> (*)" name="insurance_issued_at"
                            format="<?php echo e(Core::formatsList(Core::setting('date_format'), 0)); ?>"
                            value="<?php echo e(old('insurance_issued_at')); ?>"></neo-datepicker>
                    </div>
                    <div class="flex flex-col gap-1">
                        <label class="text-x-black font-x-thin text-base">
                            <?php echo e(__('Insurance cost')); ?> (*)
                        </label>
                        <neo-textbox rules="required"
                            errors='{"required": "<?php echo e(__('The insurance cost field is required')); ?>"}' type="number"
                            placeholder="<?php echo e(__('Insurance cost')); ?> (*)" name="insurance_cost"
                            value="<?php echo e(old('insurance_cost')); ?>"></neo-textbox>
                    </div>
                </neo-tab-outlet>
                <div class="w-full flex flex-wrap gap-6">
                    <neo-button outline type="button" id="prev" style="display: none"
                        class="w-max me-auto outline outline-1 -outline-offset-1 outline-x-prime px-6 text-base lg:text-lg font-x-huge text-x-prime hover:outline-x-acent hover:text-x-white hover:bg-x-acent focus:outline-x-acent focus:text-x-white focus:bg-x-acent focus-within:outline-x-acent focus-within:text-x-white focus-within:bg-x-acent">
                        <span><?php echo e(__('Prev')); ?></span>
                    </neo-button>
                    <neo-button id="save" style="display: none"
                        class="w-max px-6 ms-auto text-base lg:text-lg font-x-huge text-x-white bg-x-prime hover:bg-x-acent focus:bg-x-acent focus-within:bg-x-acent">
                        <span><?php echo e(__('Save')); ?></span>
                    </neo-button>
                    <neo-button outline type="button" id="next"
                        class="w-max ms-auto outline outline-1 -outline-offset-1 outline-x-prime px-6 text-base lg:text-lg font-x-huge text-x-prime hover:outline-x-acent hover:text-x-white hover:bg-x-acent focus:outline-x-acent focus:text-x-white focus:bg-x-acent focus-within:outline-x-acent focus-within:text-x-white focus-within:bg-x-acent">
                        <span><?php echo e(__('Next')); ?></span>
                    </neo-button>
                </div>
            </div>
        </neo-tab-wrapper>
    </form>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('js/vehicle/share.min.js')); ?>?v=<?php echo e(env('APP_VERSION')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('shared.core.base', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH P:\php\auto\client\resources\views/vehicle/store.blade.php ENDPATH**/ ?>